<?php
// copia il contenuto di un file in una stringa
$filename = "\hey";
$handle = fopen($filename, "r");
$html= fread($handle, filesize($filename));
fclose($handle);
?>