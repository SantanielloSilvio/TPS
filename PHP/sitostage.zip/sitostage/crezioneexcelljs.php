<html>
<head>
<title>File Excel del database</title>
<!--redirect temmporizzata-->
<meta http-equiv="refresh" content="0;URL=index.php">
<meta charset="utf-8" />

</head>
<body>

<?php

/* dichiariamo alcune importanti variabili per collegarci al database */
$host = "localhost";
$dbusername = "root";
$dbname = "dbsito";

// Create connection
$conn = mysqli_connect($host, $dbusername, '', $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT nome,cognome,email,contenuto,lavoro,sesso,eta FROM commenti";
$result = mysqli_query($conn, $sql);
$ncommenti=mysqli_affected_rows($conn);

$cont=0;
// output data of each row
while($row = mysqli_fetch_assoc($result)) {
   $nome[$cont]=$row["nome"];
   $cognome[$cont]=$row["cognome"];
   $email[$cont]=$row["email"];
   $contenuto[$cont]=$row["contenuto"];
   $lavoro[$cont]=$row["lavoro"];
   $sesso[$cont]=$row["sesso"];
   $eta[$cont]=$row["eta"];
   $cont++;
}

mysqli_close($conn);

echo '
<script type="text/javascript">

var ncommenti=' . json_encode($ncommenti) . ';
var y;
var nome=new Array();
var cognome=new Array();
var contenuto=new Array();
var lavoro=new Array();
var sesso=new Array();
var eta=new Array();

nome = ' . json_encode($nome) . ';
nome.unshift("nome");
cognome= ' . json_encode($cognome) . ';
cognome.unshift("cognome");
contenuto= ' . json_encode($contenuto) . ';
contenuto.unshift("contenuto");
lavoro= ' . json_encode($lavoro) . ';
lavoro.unshift("lavoro");
sesso= ' . json_encode($sesso) . ';
sesso.unshift("sesso");
eta= ' . json_encode($eta) . ';
eta.unshift("eta");

</script>';

?>

<![if gt IE 9]>
<script type="text/javascript" src="//unpkg.com/xlsx/dist/shim.min.js"></script>
<script type="text/javascript" src="//unpkg.com/xlsx/dist/xlsx.full.min.js"></script>

<script type="text/javascript" src="//unpkg.com/blob.js@1.0.1/Blob.js"></script>
<script type="text/javascript" src="//unpkg.com/file-saver@1.3.3/FileSaver.js"></script>
<![endif]>

<script>
function doit(type, fn, dl) {
	var elt = document.getElementById('data-table');
	var wb = XLSX.utils.table_to_book(elt, {sheet:"Sheet JS"});
	return dl ?
	XLSX.write(wb, {bookType:type, bookSST:true, type: 'base64'}) :
	XLSX.writeFile(wb, fn || ('SheetJSTableExport.' + (type || 'xlsx')));
}

//funzione per invertire la matrice
function transpose( matrix ) {
	
	var result = new Array( matrix[ 0 ].length );
	
	for ( var i = 0; i < result.length; i++ ) {
		
		result[ i ] = new Array( matrix.length );
		for ( var j = 0; j < result[ i ].length; j++ ) {
			
			result[ i ][ j ] = matrix[ j ][ i ];
		}
	}
	
	return result;
}
</script>

<div id="container"></div>

<script type="text/javascript">

/* initial table */

var aoa = [
	nome,
	cognome,
	contenuto,
    lavoro,
    sesso,
    eta
];

aoa=transpose(aoa);

var ws = XLSX.utils.aoa_to_sheet(aoa);
var html_string = XLSX.utils.sheet_to_html(ws, { id: "data-table", editable: true });
document.getElementById("container").innerHTML = html_string;
</script>
<script type="text/javascript">
doit('xlsx');
</script>

<script type="text/javascript">
function tableau(pid, iid, fmt, ofile) {
	if(typeof Downloadify !== 'undefined') Downloadify.create(pid,{
			swf: 'downloadify.swf',
			downloadImage: 'download.png',
			width: 100,
			height: 30,
			filename: ofile, data: function() { return doit(fmt, ofile, true); },
			transparent: false,
			append: false,
			dataType: 'base64',
			onComplete: function(){ alert('Your File Has Been Saved!'); },
			onCancel: function(){ alert('You have cancelled the saving of this file.'); },
			onError: function(){ alert('You must put something in the File Contents or there will be nothing to save!'); }
	}); else document.getElementById(pid).innerHTML = "";
}
tableau('xlsxbtn',  'xportxlsx',  'xlsx',  'SheetJSTableExport.xlsx');

</script>
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36810333-1']);
  _gaq.push(['_setDomainName', 'sheetjs.com']);
  _gaq.push(['_setAllowLinker', true]);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
</body>