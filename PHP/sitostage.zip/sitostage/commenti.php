<?php
/* dichiariamo alcune importanti variabili per collegarci al database */
$host = "localhost";
$dbusername = "root";
$dbname = "dbsito";

$nome= filter_input(INPUT_POST, 'nome');
$cognome= filter_input(INPUT_POST, 'cognome');
$sesso= filter_input(INPUT_POST, 'sesso');
$eta= filter_input(INPUT_POST, 'eta');
$email = filter_input(INPUT_POST, 'email');
$lavoro = filter_input(INPUT_POST, 'lavoro');
$messaggio = filter_input(INPUT_POST, "messaggioid", FILTER_DEFAULT);
$img = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));

// Create connection
$conn = new mysqli ($host, $dbusername, '', $dbname);
// Check connection
if (mysqli_connect_error()){
	die('errore di connessione ('. mysqli_connect_errno() .') '. mysqli_connect_error());
}
else{
	$sql = "INSERT INTO commenti(nome,cognome,sesso,eta,email,contenuto,lavoro,img) VALUES('$nome','$cognome','$sesso','$eta','$email','$messaggio','$lavoro','$img')";
	
	if ($conn->query($sql)){}
	else{
		echo "Error: ". $sql ." ". $conn->error;
	}
}

mysqli_close($conn);

$msg="Commenti correttamente inviato";
echo "<script type='text/javascript'>alert('$msg');</script>";

header("location: index.php#primo");
?>