<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
require 'Include/PHPMailer.php';
require 'Include/SMTP.php';
require 'Include/Exception.php';

// Load Composer's autoloader
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
$name = filter_input(INPUT_POST, 'mnome');
    $email = filter_input(INPUT_POST, 'memail');
    $message = filter_input(INPUT_POST, 'mmessaggio', FILTER_DEFAULT);
    $subject = filter_input(INPUT_POST, 'moggetto');
    
    $body ="From: $name\n E-Mail: $email\n Message:\n $message";
// Instantiation and passing `true` enables exceptions
$mail = new PHPMailer();

    //Server settings
                  // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = '69santucci69@gmail.com';                     // SMTP username
    $mail->Password   = 'Password1!1';                               // SMTP password
    $mail->SMTPSecure = 'tsl';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
    $mail->Port       = '587';                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('69santucci69@gmail.com', 'Santucci');
    $mail->addAddress($email, $name);     // Add a recipient
    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Santucci';
    $mail->Body    = 'Grazie per averci contattato! prenderemo in considerazione la sua email e le risponderemo al più presto.';
    $mail->send();
$mail->smtpClose();
$mail = new PHPMailer();
    //Server settings                   // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = '69santucci69@gmail.com';                     // SMTP username
    $mail->Password   = 'Password1!1';                               // SMTP password
    $mail->SMTPSecure = 'tsl';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
    $mail->Port       = '587';                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('69santucci69@gmail.com', 'Santucci');
    $mail->addAddress('69santucci69@gmail.com', $name);     // Add a recipient
    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = $message;
    $mail->send();
    $mail->smtpClose();
header("location: index.php#secondo");
    
